<?php
defined("BASEPATH") or exit("No direct script access allowed");
require_once APPPATH . "core/core_init.php";
$hook["post_controller_constructor"][] = array(
	"function" => "load_init_configs",
	"filename" => "init.php", "filepath" => "hooks",
	"params" => array("a4LxGy", "JGKlXB2", "cs4Wduyr")
);
