<div class="container main_body">  
<section class="section level-items has-text-centered m-t-xxl p-t-xxl">
	<h1 class="title p-b-sm">
		Page not found!
	</h1>
	<a class="button is-warning" href="<?php echo base_url(); ?>">
		<i class="fas fa-long-arrow-alt-left " style="padding-right: 5px;"></i> Dashboard
	</a>
</section>
</div>
